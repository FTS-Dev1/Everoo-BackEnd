exports.ERRORS = require("./errors");
exports.SUCCESS_MSG = require("./success");
exports.STATUS = require("./status");
exports.STATUS_CODE = require("./statusCode");
exports.ROUTES = require("./routes");
exports.ROLES = require("./roles");
exports.PERMISSIONS = require("./permission");
