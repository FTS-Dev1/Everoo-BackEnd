const PERMISSIONS = {
  READ: "read",
  READ_WRITE: "read,write",
  READ_WRITE_UPDATE: "read,write,update",
};

module.exports = PERMISSIONS;
