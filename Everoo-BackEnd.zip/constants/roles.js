module.exports = {
    USER: "user",
    ADMIN: "admin",
    SUPERADMIN: "superadmin",
    CLIENT: "client",
}