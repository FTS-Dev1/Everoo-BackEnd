const STATUS = {
  SUCCESS: "success",
  ERROR: "error",
  FAIL: "fail",
  APPROVED: "approved",
};

module.exports = STATUS;
